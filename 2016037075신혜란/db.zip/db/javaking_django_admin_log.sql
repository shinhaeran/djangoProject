-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: javaking
-- ------------------------------------------------------
-- Server version	5.5.46-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2018-12-08 12:16:01','1','Product object',1,'[{\"added\": {}}]',9,1),(2,'2018-12-08 12:16:55','1','Product object',3,'',9,1),(3,'2018-12-08 12:17:08','1','ㅇ',3,'',8,1),(4,'2018-12-08 12:23:57','2','Product object',1,'[{\"added\": {}}]',9,1),(5,'2018-12-08 12:32:41','2','1번 상품',2,'[]',8,1),(6,'2018-12-13 12:36:00','3','junghee',3,'',4,1),(7,'2018-12-13 12:37:14','4','junghee',3,'',4,1),(8,'2018-12-13 12:38:58','5','junghee',3,'',4,1),(9,'2018-12-13 12:43:14','6','junghee',3,'',4,1),(10,'2018-12-13 12:45:27','7','junghee',3,'',4,1),(11,'2018-12-13 12:46:10','8','junghee',3,'',4,1),(12,'2018-12-13 15:59:41','1','admin',2,'[{\"changed\": {\"fields\": [\"is_active\"]}}]',4,1),(13,'2018-12-13 16:04:04','1','admin',2,'[{\"changed\": {\"fields\": [\"is_active\"]}}]',4,11),(14,'2018-12-13 16:07:22','10','111',3,'',4,11),(15,'2018-12-13 16:07:22','2','haeran',3,'',4,11),(16,'2018-12-13 17:20:30','18','2',3,'',8,1),(17,'2018-12-13 17:20:30','17','1',3,'',8,1),(18,'2018-12-13 17:20:30','16','ㄹ',3,'',8,1),(19,'2018-12-13 17:20:30','15','ㅓ',3,'',8,1),(20,'2018-12-13 17:20:30','14','ㅏ',3,'',8,1),(21,'2018-12-13 17:20:30','13','3',3,'',8,1),(22,'2018-12-13 17:20:30','12','2번 상품',3,'',8,1),(23,'2018-12-13 17:20:30','2','2번 상품',3,'',8,1),(24,'2018-12-13 17:22:12','19','1번 상품',1,'[{\"added\": {}}]',8,1),(25,'2018-12-13 17:22:47','3','Product object',1,'[{\"added\": {}}]',9,1),(26,'2018-12-13 17:35:06','19','JAVA',2,'[{\"changed\": {\"fields\": [\"title\", \"text\"]}}]',8,1),(27,'2018-12-13 17:35:18','3','Product object',2,'[{\"changed\": {\"fields\": [\"quantity\"]}}]',9,1),(28,'2018-12-13 17:35:51','20','C++',1,'[{\"added\": {}}]',8,1),(29,'2018-12-13 17:36:21','21','C',1,'[{\"added\": {}}]',8,1),(30,'2018-12-13 17:37:23','22','PYTHON',1,'[{\"added\": {}}]',8,1),(31,'2018-12-13 17:38:09','23','C#',1,'[{\"added\": {}}]',8,1),(32,'2018-12-13 17:38:34','24','RUBY',1,'[{\"added\": {}}]',8,1),(33,'2018-12-13 17:39:04','4','Product object',1,'[{\"added\": {}}]',9,1),(34,'2018-12-13 17:39:14','5','Product object',1,'[{\"added\": {}}]',9,1),(35,'2018-12-13 17:39:25','5','Product object',2,'[{\"changed\": {\"fields\": [\"price\", \"quantity\"]}}]',9,1),(36,'2018-12-13 17:39:37','6','Product object',1,'[{\"added\": {}}]',9,1),(37,'2018-12-13 17:40:01','7','Product object',1,'[{\"added\": {}}]',9,1),(38,'2018-12-13 17:40:10','6','Product object',2,'[{\"changed\": {\"fields\": [\"price\", \"quantity\"]}}]',9,1),(39,'2018-12-13 17:40:23','5','Product object',2,'[{\"changed\": {\"fields\": [\"price\", \"quantity\"]}}]',9,1),(40,'2018-12-13 17:40:29','4','Product object',2,'[{\"changed\": {\"fields\": [\"price\", \"quantity\"]}}]',9,1),(41,'2018-12-13 17:40:42','3','Product object',2,'[{\"changed\": {\"fields\": [\"price\", \"quantity\"]}}]',9,1),(42,'2018-12-13 17:40:59','8','Product object',1,'[{\"added\": {}}]',9,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-14  6:26:03
