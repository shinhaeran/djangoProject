-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: javaking
-- ------------------------------------------------------
-- Server version	5.5.46-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blog_post`
--

DROP TABLE IF EXISTS `blog_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `text` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_post`
--

LOCK TABLES `blog_post` WRITE;
/*!40000 ALTER TABLE `blog_post` DISABLE KEYS */;
INSERT INTO `blog_post` VALUES (20,'C++','C++은 C 언어에 객체지향의 개념을 더한 언어이다. AT&T 벨 연구소에서 일하던 비야네 스트롭스트룹(Bjarne Stroustrup)이 만들었다. 원래 이름은 C with Classes였으나 증가 연산자(++) 기능을 더하면서 1984년에 이름이 C++로 바뀌었다.','2018-12-13 17:35:51','2018-12-13 17:35:51'),(21,'C','현재 가장 널리 쓰이는 명령형 언어는 C 언어이다. C 언어는 포트란 Ⅰ을 토대로 알골 60을 거쳐 AT&T 벨 연구소에서 일하던 데니스 리치(Dennis Ritchie)에 의해 1971년에 만들어졌다. 대다수 컴퓨터 구조와 운영체제가 C 컴파일러를 갖고 있어 거의 모든 환경에 사용할 수 있다.','2018-12-13 17:36:21','2018-12-13 17:36:21'),(22,'PYTHON','플랫폼 독립적이기 때문에 다양한 플랫폼에서 사용 가능하고 또한 기본 제공되는 라이브러리가 매우 많다. \r\nC언어와 다르게 인터프리터식 동적 타이핑(Dynamically typed) 대화형 언어이다. 인터프리터 형식이기 때문에 사용자가 컴파일을 하지 않고서도 작성한 프로그램을 바로 실행할 수 있을 뿐만 아니라, 한 줄 단위로 실행되기 때문에 사용자가 쉽게 결과를 확인할 수 있다.\r\n[네이버 지식백과] 파이썬 [python] (두산백과)','2018-12-13 17:37:23','2018-12-13 17:37:23'),(23,'C#','모든 것을 객체로 취급하는 컴포넌트 프로그래밍언어. C++(시플러스플러스)에 기본을 두고, 비주얼베이직(visual basic)의 편의성을 결합하여 만든 객체지향 프로그래밍언어이다.','2018-12-13 17:38:09','2018-12-13 17:38:09'),(24,'RUBY','일본의 마쓰모토 유키히로가 개발한 인터프리터 방식의 객체 지향 스크립트 언어. 스몰토크(Smalltalk)와 같은 순수 객체 지향 언어의 장점과 펄(Perl)의 텍스트 처리 능력, 그리고 오크(awk)의 정규 표현 특성이 잘 결합된 공개 소프트웨어이다. 일반 변수나 식에는 형 선언이 없어 프로그램이 간결하여 유연하며, 가비지 콜렉션(garbage collection)과 스레드(thread) 기능도 있다.','2018-12-13 17:38:34','2018-12-13 17:38:34'),(25,'JAVA','내가 제일 좋아하는 언어이다.','2018-12-13 20:57:21','2018-12-13 20:57:21');
/*!40000 ALTER TABLE `blog_post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-14  6:26:02
