from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

from datetime import date

class UserManager(BaseUserManager):
    def create_user(self, username, email=None, password=None, **extra_fields):
        try:
            user = self.model(
                username=username,
                email=email,
            )
            extra_fields.setdefault('is_staff', False)
            extra_fields.setdefault('is_superuser', False)
            user.set_password(password)
            user.is_active = True
            user.save()
            return user
        except Exception as e:
            print(e)

    def create_superuser(self, username, email=None, password=None, **extra_fields):
            try:
                superuser = self.create_user(
                    username=username,
                    password=password,
                    email=email,
                )
                superuser.is_admin = True
                superuser.is_superuser = True
                superuser.is_active = True
                superuser.is_staff = True
                superuser.save()
                return superuser
            except Exception as e:
                print(e)

class User(AbstractBaseUser, PermissionsMixin):
    # Default : id / password / last_login / is_superuser / username / first_name / last_name / email / is_staff / is_active / date_joined
    # Default : id / password / last_login
    email = models.EmailField(max_length=100, null=False)
    username = models.CharField(max_length=20, unique=True)
    
    is_staff = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    object = UserManager()

    permission = (("can_mark_returned", "Set book as returned"),)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']



# Create your models here.

